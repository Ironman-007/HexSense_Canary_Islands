#pragma once

#ifdef __cplusplus
extern "C" {
#endif

extern void display_loop(void);

extern void capture_loop(void);
#ifdef __cplusplus
}
#endif
