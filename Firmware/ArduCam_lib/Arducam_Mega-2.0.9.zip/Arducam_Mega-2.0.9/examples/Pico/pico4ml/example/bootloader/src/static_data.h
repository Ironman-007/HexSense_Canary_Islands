#pragma once

#include "gui_func.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const unsigned char start_pic[];
extern const unsigned char func_pic[];
extern const UI_LOG_MSG_T start_loc;
extern const UI_LOG_MSG_T func_loc;
#ifdef __cplusplus
}
#endif