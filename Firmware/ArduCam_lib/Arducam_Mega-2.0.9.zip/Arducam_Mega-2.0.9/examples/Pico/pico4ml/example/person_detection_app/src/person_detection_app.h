#pragma once


#ifdef __cplusplus
extern "C"
{
#endif
    extern void app_loop(void);
#ifdef __cplusplus
}
#endif
