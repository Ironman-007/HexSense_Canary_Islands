#define CAMERA_SPI_PORT spi1
#define CAMERA_MISO_PIN 12
#define CAMERA_MOSI_PIN 11
#define CAMERA_SCK_PIN  10

// #define SD_SPI_PORT    spi0
// #define SD_MISO_PIN    16
// #define SD_MOSI_PIN    19
// #define SD_SCK_PIN     18